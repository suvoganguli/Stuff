#define DINT

#include "amd_1.c"
