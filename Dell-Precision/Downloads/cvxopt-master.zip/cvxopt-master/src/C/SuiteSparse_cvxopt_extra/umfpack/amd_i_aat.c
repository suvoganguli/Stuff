#define DINT

#include "amd_aat.c"
