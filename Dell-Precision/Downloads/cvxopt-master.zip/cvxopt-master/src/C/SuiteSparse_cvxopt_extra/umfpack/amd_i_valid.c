#define DINT

#include "amd_valid.c"
