#define DINT
#define FIXQ
#include "umf_assemble.c"
