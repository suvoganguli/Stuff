#define DINT
#include "umf_set_stats.c"
