#define DLONG

#include "umf_get_memory.c"
