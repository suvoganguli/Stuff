#define DLONG

#include "umf_kernel.c"
