#define DLONG

#include "umf_local_search.c"
