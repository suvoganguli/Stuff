#define DLONG

#include "umf_mem_alloc_element.c"
