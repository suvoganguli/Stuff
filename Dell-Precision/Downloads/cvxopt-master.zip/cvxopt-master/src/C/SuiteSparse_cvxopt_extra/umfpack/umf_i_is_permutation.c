#define DINT
#include "umf_is_permutation.c"
