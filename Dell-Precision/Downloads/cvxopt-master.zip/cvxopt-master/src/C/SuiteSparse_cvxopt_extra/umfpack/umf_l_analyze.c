#define DLONG

#include "umf_analyze.c"
