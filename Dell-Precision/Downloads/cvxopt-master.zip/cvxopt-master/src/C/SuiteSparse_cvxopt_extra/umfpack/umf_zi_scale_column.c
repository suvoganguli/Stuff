#define ZINT
#include "umf_scale_column.c"
