#define ZLONG

#include "umf_init_front.c"
