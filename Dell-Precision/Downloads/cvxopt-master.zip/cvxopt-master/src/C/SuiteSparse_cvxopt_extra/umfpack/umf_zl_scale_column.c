#define ZLONG

#include "umf_scale_column.c"
