#define DINT
#include "umfpack_qsymbolic.c"
