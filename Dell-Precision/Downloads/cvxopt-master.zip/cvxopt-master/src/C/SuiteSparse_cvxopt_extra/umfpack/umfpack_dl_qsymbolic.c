#define DLONG

#include "umfpack_qsymbolic.c"
