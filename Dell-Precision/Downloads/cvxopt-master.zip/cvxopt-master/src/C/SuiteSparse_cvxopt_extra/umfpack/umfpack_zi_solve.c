#define ZINT
#include "umfpack_solve.c"
