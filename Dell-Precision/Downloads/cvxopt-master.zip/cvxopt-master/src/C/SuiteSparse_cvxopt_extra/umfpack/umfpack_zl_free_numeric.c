#define ZLONG

#include "umfpack_free_numeric.c"
