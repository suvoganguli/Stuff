#define ZLONG

#include "umfpack_qsymbolic.c"
